import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите арифметическое выражение (например, 3 + 5):");
        String input = scanner.nextLine();
        try {
            String result = calc(input);
            System.out.println("Результат: " + result);
        } catch (Exception e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
        scanner.close();
    }
    public static String calc(String input) throws Exception {
        String[] parts = input.split("\\s+");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Некорректное выражение");
        }
        int num1 = parseNumber(parts[0]);
        int num2 = parseNumber(parts[2]);
        char operator = parts[1].charAt(0);

        int result;
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 == 0) {
                    throw new ArithmeticException("Деление на ноль");
                }
                result = num1 / num2;
                break;
            default:
                throw new IllegalArgumentException("Некорректная операция");
        }
        return num1 > 0 && num1 <= 10 && num2 > 0 && num2 <= 10 ? convertToOutputFormat(result, input) : null;
    }
    private static int parseNumber(String str) throws Exception {
        try {
            return RomanConverter.isRoman(str) ? RomanConverter.romanToArabic(str) : Integer.parseInt(str);
        } catch (NumberFormatException e) {
            throw new Exception("Некорректное число: " + str);
        }
    }
    private static String convertToOutputFormat(int result, String input) {
        return RomanConverter.isRoman(input) ? RomanConverter.arabicToRoman(result) : Integer.toString(result);
    }
}
class RomanConverter {
    private static final String[] romanSymbols = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

    public static boolean isRoman(String str) {
        for (String symbol : romanSymbols) {
            if (symbol.equals(str)) {
                return true;
            }
        }
        return false;
    }
    public static int romanToArabic(String roman) {
        for (int i = 0; i < romanSymbols.length; i++) {
            if (romanSymbols[i].equals(roman)) {
                return i + 1;
            }
        }
        return 0; // Should not happen if isRoman() is checked before calling this method
    }
    public static String arabicToRoman(int arabic) {
        if (arabic < 1 || arabic > 10) {
            throw new IllegalArgumentException("Некорректное число для преобразования в римскую форму");
        }
        return romanSymbols[arabic - 1];
    }
}